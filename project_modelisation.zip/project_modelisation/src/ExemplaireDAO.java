import java.sql.*;

public class ExemplaireDAO {

    public static boolean verifierExemplaireExiste(String RFID) {
        String sql = "SELECT COUNT(*) FROM exemplaire WHERE RFID = ? AND disponible = 1";

        try (Connection con = TestConnexion.getConnexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, RFID);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    return count > 0; // vrai s'il existe au moins un et est dispo
                }

            }
            int rowsUpdated = ps.executeUpdate();

            return rowsUpdated > 0; // true si au moins une ligne a été mise à jour
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean marquerExemplaireEmprunte(String RFID) { String sql = "UPDATE exemplaire SET disponible = 0 WHERE RFID = ?";
        try (Connection con = TestConnexion.getConnexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, RFID);
            int rows = ps.executeUpdate();
            return rows > 0; // true si au moins une ligne modifiée
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
